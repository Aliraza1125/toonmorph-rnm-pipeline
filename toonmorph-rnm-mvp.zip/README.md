# ToonMorph RNM MVP

Simple Next.js + Tailwind scaffold to preview Rick & Morty–style scenes.

## Run
npm i && npm run dev

## Pages
/ - Home
/create - Scene builder
/dashboard - Demo dashboard
/subscribe - Placeholder billing
/view/[id] - Demo episode
